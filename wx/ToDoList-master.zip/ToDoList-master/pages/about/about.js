Page({
  data: {
      src:"../../images/minapp_qr_code.jpg"
  }
});
